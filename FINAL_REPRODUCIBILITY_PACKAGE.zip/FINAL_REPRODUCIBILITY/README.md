# Reproducibility Package
## scVI- and RNA Velocity–Integrated Fate Dynamics Reveal Latent Stability Architecture in Melanoma Therapy Resistance
**Author:** Pranshu Bharadwaj, Research Scholar, Avsath Vidya Sansthan, Gujarat

---

## Overview

This package contains all computational code and results needed to reproduce the analyses and figures reported in the manuscript. The pipeline runs on the real Tirosh et al. (2016) melanoma single-cell RNA-seq dataset (GEO accession GSE72056, 800 cells, 23,686 genes filtered to 12,636 expressed genes).

---

## Dataset

| Property | Value |
|---|---|
| Source | Tirosh et al. (2016) *Science* 352:189 |
| GEO accession | GSE72056 |
| File | `tirosh_raw.txt.gz` (download from GEO) |
| Cells used | 800 (400 malignant/resistant + 400 non-malignant/sensitive) |
| Genes after filtering | 12,636 |

Download the raw data from: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE72056

---

## Repository Structure

```
FINAL_REPRODUCIBILITY/
├── README.md                        ← This file
├── requirements.txt                 ← Python dependencies
│
├── code/
│   ├── 01_run_real_pipeline.py      ← Main pipeline (preprocessing → scVI → Markov → KL)
│   ├── 02_generate_paper_figures.py ← Generates Figures 2–6 from pipeline outputs
│   ├── 03_generate_conceptual_figure.py ← Generates Figure 1 (conceptual framework)
│   └── 04_generate_table2.py        ← Generates Table 2 (statistics summary PNG)
│
├── figures/
│   ├── paper_figures/
│   │   ├── Fig1_Conceptual_Framework.png    ← Figure 1: 5-panel conceptual schematic
│   │   ├── Fig1_scVI_latent_manifold.png    ← Figure 2: scVI/scANVI latent embedding
│   │   ├── Fig2_fate_maps.png               ← Figure 3: Fate map heatmaps
│   │   ├── Fig3_velocity_stream.png         ← Figure 4: RNA velocity streamlines
│   │   ├── Fig4_fate_landscape.png          ← Figure 5: Absorbing fate landscape
│   │   ├── Fig5_divergence_scoring.png      ← Figure 6: KL divergence scoring
│   │   └── Fig6_framework_overview.png      ← Figure 7: Framework overview
│   └── supplementary/
│       └── Table2_statistics.png            ← Table 2: Quantitative statistics
│
├── results/
│   ├── numerical_results.json               ← All key numerical outputs
│   └── numpy_arrays/
│       ├── fate_map_scanvi.npy              ← Fate map matrix (720 × 80), scANVI
│       ├── fate_map_velocity.npy            ← Fate map matrix (720 × 80), velocity
│       ├── fate_map_perturbation.npy        ← Fate map matrix (720 × 80), perturbed
│       ├── kl_divergence_diffusion.npy      ← Per-cell KL divergence, diffusion model (720,)
│       ├── kl_divergence_perturbation.npy   ← Per-cell KL divergence, perturbation (720,)
│       └── js_drug_score.npy                ← Jensen–Shannon drug score per cell (720,)
│
└── data/
    └── (place tirosh_raw.txt.gz here before running)
```

---

## Execution Order

Run scripts in numbered order:

```bash
# Step 1 — Full pipeline (preprocessing, scVI training, Markov chain, KL scoring)
python code/01_run_real_pipeline.py

# Step 2 — Generate publication figures (Figures 2–6)
python code/02_generate_paper_figures.py

# Step 3 — Generate conceptual framework figure (Figure 1)
python code/03_generate_conceptual_figure.py

# Step 4 — Generate Table 2 statistics PNG
python code/04_generate_table2.py
```

---

## Key Results Summary

| Metric | Value |
|---|---|
| Cells total | 800 |
| Genes after filtering | 12,636 |
| Terminal states | 80 |
| Transient cells | 720 |
| Resistant transient (n) | 386 |
| Sensitive transient (n) | 334 |
| KL divergence — Resistant (mean ± SD) | 11.622 ± 2.648 |
| KL divergence — Sensitive (mean ± SD) | 12.332 ± 4.335 |
| Mann–Whitney p-value | 2.74 × 10⁻⁶ |
| Randomised control p-value | 0.5923 (non-significant) |

**Central finding:** Resistant melanoma populations exhibit reduced perturbation-induced fate redistribution, consistent with their occupation of dynamically stable attractor regions in transcriptomic state space.

---

## Table 2 — Corrected Final Version

| Dynamical model | Resistant (mean KL ± SD) | Sensitive (mean KL ± SD) | p-value | Interpretation |
|---|---|---|---|---|
| Diffusion-derived fate model | 11.622 ± 2.648 | 12.332 ± 4.335 | 2.74 × 10⁻⁶ | Resistant populations exhibit reduced perturbation-induced fate redistribution |
| Uniform scaling control | 0.000 ± 0.000 | 0.000 ± 0.000 | 0.1814 | Uniform row-wise scaling preserves stochastic structure after normalization |
| Randomised control (permuted labels) | 12.043 ± 3.470 | 11.846 ± 3.638 | 0.5923 | No significant separation observed following label permutation |

> Because uniform row-wise scaling is cancelled during stochastic renormalization of the transition operator, the corresponding perturbation acts as a structural invariance control rather than a biologically effective perturbation.

---

## Python Environment

Tested with Python 3.11. Install dependencies:

```bash
pip install -r requirements.txt
```

---

## Figure Index

| Figure | File | Description |
|---|---|---|
| Fig. 1 (Conceptual) | Fig1_Conceptual_Framework.png | 5-panel Nature-style schematic of full framework |
| Fig. 2 | Fig1_scVI_latent_manifold.png | scVI/scANVI latent space embedding, coloured by cell state |
| Fig. 3 | Fig2_fate_maps.png | Absorbing Markov fate map heatmaps (resistant vs sensitive) |
| Fig. 4 | Fig3_velocity_stream.png | RNA velocity streamline plot over latent manifold |
| Fig. 5 | Fig4_fate_landscape.png | Fate landscape with diffusion vs velocity difference map |
| Fig. 6 | Fig5_divergence_scoring.png | Per-cell KL divergence distributions |
| Fig. 7 | Fig6_framework_overview.png | Integrated framework overview |
| Table 2 | Table2_statistics.png | Quantitative comparison table (publication-ready PNG) |

---

## Citation

Bharadwaj P. scVI- and RNA Velocity–Integrated Fate Dynamics Reveal Latent Stability Architecture in Melanoma Therapy Resistance. Avsath Vidya Sansthan, Gujarat. 2024.

Dataset: Tirosh I, et al. Dissecting the multicellular ecosystem of metastatic melanoma by single-cell RNA-seq. *Science*. 2016;352(6282):189–196. doi:10.1126/science.aad0501
