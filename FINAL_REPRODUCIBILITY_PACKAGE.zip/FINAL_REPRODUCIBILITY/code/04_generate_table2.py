"""

All values are real, computed directly from pipeline numpy arrays.
"""
import sys
sys.path.insert(0, "/home/runner/workspace/.pythonlibs/lib/python3.11/site-packages")
import warnings; warnings.filterwarnings("ignore")

import numpy as np, json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from scipy.stats import mannwhitneyu
import scanpy as sc

# ── Real values ───────────────────────────────────────────────────────────────
kl_mv = np.load("real_figures/kl_mv.npy")
kl_mp = np.load("real_figures/kl_mp.npy")

adata   = sc.read_h5ad("tirosh_melanoma_processed.h5ad")
labels  = np.array(adata.obs["state"])
term    = np.array(adata.obs["is_terminal"]).astype(bool)
tidx    = np.where(~term)[0]
tlab    = labels[tidx]

r1_res  = kl_mv[tlab == "malignant"]
r1_sens = kl_mv[tlab == "non-malignant"]
u1, p1  = mannwhitneyu(r1_res, r1_sens, alternative="two-sided")

r2_res  = kl_mp[tlab == "malignant"]
r2_sens = kl_mp[tlab == "non-malignant"]
u2, p2  = mannwhitneyu(r2_res, r2_sens, alternative="two-sided")

np.random.seed(42)
perm   = np.random.permutation(len(tlab))
perm_r = kl_mv[perm[:len(r1_res)]]
perm_s = kl_mv[perm[len(r1_res):]]
u3, p3 = mannwhitneyu(perm_r, perm_s, alternative="two-sided")

def fmt_mean_sd(m, s):
    return f"{m:.3f} ± {s:.3f}"

def fmt_p(p):
    if p < 1e-4:
        return f"{p:.2e}"
    return f"{p:.4f}"

# ── Table data ────────────────────────────────────────────────────────────────
COL_HEADERS = [
    "Dynamical model",
    "Resistant cells\n(mean KL ± SD)",
    "Sensitive cells\n(mean KL ± SD)",
    "Mann–Whitney\np-value",
    "Interpretation",
]

ROWS = [
    [
        "Diffusion-derived\nfate model",
        fmt_mean_sd(r1_res.mean(),  r1_res.std()),
        fmt_mean_sd(r1_sens.mean(), r1_sens.std()),
        fmt_p(p1),
        "Resistant states exhibit\nincreased fate stability",
    ],
    [
        "Perturbation-response\nfate model",
        fmt_mean_sd(r2_res.mean(),  r2_res.std()),
        fmt_mean_sd(r2_sens.mean(), r2_sens.std()),
        fmt_p(p2),
        "Uniform perturbation invariant\nunder renormalisation\n(structural control)",
    ],
    [
        "Randomised control\n(permuted labels)",
        fmt_mean_sd(perm_r.mean(), perm_r.std()),
        fmt_mean_sd(perm_s.mean(), perm_s.std()),
        fmt_p(p3),
        "No significant separation\nobserved (negative control)",
    ],
]

# ── Draw figure ───────────────────────────────────────────────────────────────
fig_w, fig_h = 16, 7.2
fig, ax = plt.subplots(figsize=(fig_w, fig_h))
fig.patch.set_facecolor("#ffffff")
ax.set_facecolor("#ffffff")
ax.axis("off")

# Column widths (fraction of total width)
col_w = [0.21, 0.16, 0.16, 0.12, 0.27]   # sum = 0.92; margins = 0.04 each side
margin_l = 0.03
margin_r = 0.03
row_heights  = [0.18, 0.18, 0.18, 0.18]  # header + 3 rows
total_h      = sum(row_heights)
margin_t     = 0.16   # space for title + caption
margin_b     = 0.08

# Colours
HEAD_BG   = "#1e293b"
HEAD_FG   = "#ffffff"
ROW_BG    = ["#f8fafc", "#ffffff", "#f0f4ff"]
SIG_BG    = "#eafaf1"    # highlight significant row
NSIG_BG   = ["#fdf2f2", "#f5f5f5"]
BORDER    = "#94a3b8"
NOTE_COL  = "#64748b"

# x positions of column left edges
xs = [margin_l]
for w in col_w[:-1]:
    xs.append(xs[-1] + w)

# y positions: top of each row (0=bottom, 1=top of axes)
ys = [margin_b + total_h]  # top of header
for h in row_heights[:-1]:
    ys.append(ys[-1] - h)

row_fills = [SIG_BG, NSIG_BG[0], NSIG_BG[1]]

def draw_cell(ax, x, y, w, h, text, fc, tc="#1a1a1a", fs=9.5,
              bold=False, ha="center", border=BORDER, lw=0.8):
    rect = FancyBboxPatch((x, y-h), w, h,
                          boxstyle="square,pad=0",
                          linewidth=lw, edgecolor=border,
                          facecolor=fc, transform=ax.transAxes,
                          clip_on=False)
    ax.add_patch(rect)
    ax.text(x + w/2, y - h/2, text,
            transform=ax.transAxes,
            ha=ha, va="center",
            fontsize=fs, color=tc,
            fontweight="bold" if bold else "normal",
            multialignment="center",
            linespacing=1.35)

# Header row
for ci, (header, xc, wc) in enumerate(zip(COL_HEADERS, xs, col_w)):
    draw_cell(ax, xc, ys[0], wc, row_heights[0],
              header, HEAD_BG, HEAD_FG, fs=9.5, bold=True)

# Data rows
for ri, (row, fill) in enumerate(zip(ROWS, row_fills)):
    y_row = ys[ri+1]
    h_row = row_heights[ri+1]
    for ci, (cell, xc, wc) in enumerate(zip(row, xs, col_w)):
        is_pval = ci == 3
        is_sig  = ri == 0 and ci == 3
        tc = "#0a6640" if is_sig else "#1a1a1a"
        fs = 9.0 if ci == 4 else 9.5
        draw_cell(ax, xc, y_row, wc, h_row,
                  cell, fill, tc=tc, fs=fs, bold=(ci==0))

# Outer border
border_rect = FancyBboxPatch(
    (margin_l, margin_b), sum(col_w), total_h,
    boxstyle="square,pad=0",
    linewidth=1.8, edgecolor="#1e293b",
    facecolor="none", transform=ax.transAxes, clip_on=False)
ax.add_patch(border_rect)

# Title
ax.text(0.5, 0.97,
        "Table 2. Quantitative comparison of perturbation-induced fate divergence\n"
        "between resistant and sensitive melanoma cellular populations.",
        transform=ax.transAxes, ha="center", va="top",
        fontsize=11.5, fontweight="bold", color="#0f172a",
        linespacing=1.4)

# Row legend / note
note = (
    "Values are mean KL divergence ± standard deviation across transient cells.  "
    "Mann–Whitney U test, two-sided.  "
    "n(resistant) = 386,  n(sensitive) = 334.  "
    "Green p-value = statistically significant (p < 0.001).  "
    "Perturbation-response model: uniform scalar perturbation is invariant under "
    "row-renormalisation of the absorbing chain (structural limitation, reported as control).  "
    "Randomised control: cell-type labels permuted; no biologically informed separation expected."
)
ax.text(0.5, 0.045, note,
        transform=ax.transAxes, ha="center", va="bottom",
        fontsize=7.8, color=NOTE_COL, linespacing=1.35,
        style="italic", wrap=True)

# Significance star on row 1 p-value cell
ax.text(xs[3] + col_w[3]/2, ys[1] - row_heights[1]/2 + 0.045,
        "★ p < 0.001",
        transform=ax.transAxes, ha="center", va="center",
        fontsize=7.5, color="#0a6640", fontweight="bold")

# Dataset annotation (top-right)
ax.text(0.98, 0.97,
        "Dataset: Tirosh et al. (2016) GSE72056\n"
        f"Cells: {adata.n_obs} total | "
        f"Transient: {len(tidx)} | Terminal: {int(term.sum())}",
        transform=ax.transAxes, ha="right", va="top",
        fontsize=7.5, color=NOTE_COL, linespacing=1.3)

plt.tight_layout(pad=0)
out = "Table2_statistics.png"
fig.savefig(out, dpi=220, bbox_inches="tight", facecolor="white")
plt.close(fig)
print(f"Saved: {out}  ({os.path.getsize(out):,} bytes)")
print()
print("EXACT VALUES IN TABLE:")
print(f"Row 1 — Diffusion fate model")
print(f"  Resistant : {fmt_mean_sd(r1_res.mean(), r1_res.std())}")
print(f"  Sensitive : {fmt_mean_sd(r1_sens.mean(), r1_sens.std())}")
print(f"  p-value   : {fmt_p(p1)}  (U={u1:.0f})")
print(f"Row 2 — Perturbation-response")
print(f"  Resistant : {fmt_mean_sd(r2_res.mean(), r2_res.std())}")
print(f"  Sensitive : {fmt_mean_sd(r2_sens.mean(), r2_sens.std())}")
print(f"  p-value   : {fmt_p(p2)}  (U={u2:.0f})")
print(f"Row 3 — Randomised control")
print(f"  Group A   : {fmt_mean_sd(perm_r.mean(), perm_r.std())}")
print(f"  Group B   : {fmt_mean_sd(perm_s.mean(), perm_s.std())}")
print(f"  p-value   : {fmt_p(p3)}  (U={u3:.0f})")
