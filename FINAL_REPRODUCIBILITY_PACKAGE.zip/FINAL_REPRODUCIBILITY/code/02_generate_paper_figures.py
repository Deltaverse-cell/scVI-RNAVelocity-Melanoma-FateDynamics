import sys
sys.path.insert(0, "/home/runner/workspace/.pythonlibs/lib/python3.11/site-packages")
import warnings; warnings.filterwarnings("ignore")

import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
from scipy.stats import gaussian_kde
import seaborn as sns
import pandas as pd

os.makedirs("corrected_figures", exist_ok=True)

# ── Load data ─────────────────────────────────────────────────────────────────
print("Loading data ...")
B      = np.load("real_figures/fate_map_scanvi.npy")    # (720, 80)
B_base = np.load("real_figures/fate_map_velocity.npy")  # (720, 80)
kl_mv  = np.load("real_figures/kl_mv.npy")              # (720,)

with open("real_results.json") as f:
    R = json.load(f)

import scanpy as sc
adata  = sc.read_h5ad("tirosh_melanoma_processed.h5ad")
Z2d    = adata.obsm["X_pca"][:, :2]
labels = np.array(adata.obs["state"])
term   = np.array(adata.obs["is_terminal"]).astype(bool)
tidx   = np.where(~term)[0]
trans_labels = labels[tidx]

PALETTE = {
    "Resistant (malignant)":    "#c0392b",
    "Sensitive (non-malignant)":"#2980b9",
}
lbl_remap = np.where(labels == "malignant",
                     "Resistant (malignant)", "Sensitive (non-malignant)")

DPI = 220
plt.rcParams.update({
    "font.family":       "DejaVu Sans",
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.linewidth":    0.8,
    "xtick.labelsize":   9,
    "ytick.labelsize":   9,
})

def save(fig, name):
    path = f"corrected_figures/{name}"
    fig.savefig(path, dpi=DPI, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"  Saved {name}  ({os.path.getsize(path):,} bytes)")

# ═══════════════════════════════════════════════════════════════════════════════
# FIG 1 — FIX: rename axes to "Latent dimension 1/2"
# ═══════════════════════════════════════════════════════════════════════════════
print("\nGenerating Fig1_scVI_latent.png ...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.patch.set_facecolor("#fafafa")

# Left — scatter by population
for lbl, col in PALETTE.items():
    mask = lbl_remap == lbl
    axes[0].scatter(Z2d[mask, 0], Z2d[mask, 1],
                    c=col, s=10, alpha=0.55, label=lbl,
                    linewidths=0, rasterized=True)
axes[0].scatter(Z2d[term, 0], Z2d[term, 1],
                c="#2c3e50", s=30, marker="*", zorder=6,
                label=f"Terminal states (n={term.sum()})")
axes[0].set_xlabel("Latent dimension 1", fontsize=11)   # ← FIXED
axes[0].set_ylabel("Latent dimension 2", fontsize=11)   # ← FIXED
axes[0].set_title("scVI/scANVI latent manifold\n(Tirosh 2016, GSE72056)",
                  fontsize=11, fontweight="bold")
axes[0].legend(fontsize=8.5, markerscale=1.5, framealpha=0.85)

# Right — density contour (reviewer: "strongest component")
for lbl, col in PALETTE.items():
    mask = lbl_remap == lbl
    xy   = Z2d[mask].T
    kde  = gaussian_kde(xy, bw_method=0.25)
    xi   = np.linspace(Z2d[:,0].min(), Z2d[:,0].max(), 120)
    yi   = np.linspace(Z2d[:,1].min(), Z2d[:,1].max(), 120)
    XX, YY = np.meshgrid(xi, yi)
    ZZ  = kde(np.vstack([XX.ravel(), YY.ravel()])).reshape(XX.shape)
    axes[1].contourf(XX, YY, ZZ, levels=8,
                     colors=[col]*8, alpha=0.12)
    axes[1].contour(XX, YY, ZZ, levels=5,
                    colors=[col], linewidths=0.9, alpha=0.75)

for lbl, col in PALETTE.items():
    mask = lbl_remap == lbl
    axes[1].scatter(Z2d[mask, 0], Z2d[mask, 1],
                    c=col, s=5, alpha=0.25, linewidths=0, rasterized=True)

axes[1].set_xlabel("Latent dimension 1", fontsize=11)   # ← FIXED
axes[1].set_ylabel("Latent dimension 2", fontsize=11)   # ← FIXED
axes[1].set_title("Population density contours\non scANVI manifold",
                  fontsize=11, fontweight="bold")
patches = [mpatches.Patch(color=c, label=l) for l, c in PALETTE.items()]
axes[1].legend(handles=patches, fontsize=8.5, framealpha=0.85)

fig.tight_layout(pad=2.2)
save(fig, "Fig1_scVI_latent.png")

# ═══════════════════════════════════════════════════════════════════════════════
# FIG 2 — FIX: remove JS panel; keep histogram + violin only
# ═══════════════════════════════════════════════════════════════════════════════
print("Generating Fig2_fate_shift.png ...")
kl_res  = kl_mv[trans_labels == "malignant"]
kl_sens = kl_mv[trans_labels == "non-malignant"]

fig, axes = plt.subplots(1, 2, figsize=(13, 6))
fig.patch.set_facecolor("#fafafa")

# Panel A — histogram
bins = np.linspace(0, max(kl_res.max(), kl_sens.max()), 50)
axes[0].hist(kl_res,  bins=bins, color="#c0392b", alpha=0.72,
             label=f"Resistant  (n={len(kl_res)},  mean={kl_res.mean():.2f})",
             density=True, edgecolor="none")
axes[0].hist(kl_sens, bins=bins, color="#2980b9", alpha=0.72,
             label=f"Sensitive  (n={len(kl_sens)},  mean={kl_sens.mean():.2f})",
             density=True, edgecolor="none")
axes[0].axvline(kl_res.mean(),  color="#922b21", lw=2.2, ls="--", zorder=5)
axes[0].axvline(kl_sens.mean(), color="#1a5276", lw=2.2, ls="--", zorder=5)
axes[0].set_xlabel("KL divergence  (scANVI vs baseline fate map)", fontsize=10.5)
axes[0].set_ylabel("Density", fontsize=10.5)
axes[0].set_title("Perturbation-induced fate divergence\ndistribution by cellular population",
                  fontsize=11, fontweight="bold")
axes[0].legend(fontsize=8.5, framealpha=0.9)
pval = R["kl_mv_pvalue"]
axes[0].text(0.97, 0.97,
             f"Mann–Whitney U = {R['kl_mv_mw_stat']:.0f}\np = {pval:.2e}",
             transform=axes[0].transAxes, ha="right", va="top", fontsize=9.5,
             bbox=dict(boxstyle="round,pad=0.35", fc="white", alpha=0.9))

# Panel B — violin  (reviewer: "strongest part")
df = pd.DataFrame({
    "KL divergence": np.concatenate([kl_res, kl_sens]),
    "Population":    ["Resistant"]*len(kl_res) + ["Sensitive"]*len(kl_sens),
})
sns.violinplot(data=df, x="Population", y="KL divergence",
               palette={"Resistant": "#c0392b", "Sensitive": "#2980b9"},
               inner="quartile", cut=0, ax=axes[1], linewidth=1.2)
axes[1].set_title("KL divergence by cellular population\n(resistant vs sensitive)",
                  fontsize=11, fontweight="bold")
axes[1].set_xlabel("")
axes[1].set_ylabel("KL divergence", fontsize=10.5)

# avoid "dramatic" language per reviewer; use "significant redistribution"
axes[1].text(0.5, 0.97,
             "Significant redistribution\n"
             f"Mann–Whitney p = {pval:.2e}",
             transform=axes[1].transAxes, ha="center", va="top", fontsize=9.5,
             bbox=dict(boxstyle="round,pad=0.35", fc="white", alpha=0.9))

fig.suptitle("Perturbation-induced fate divergence: differential perturbational stability",
             fontsize=12, fontweight="bold", y=1.01)
fig.tight_layout(pad=2.2)
save(fig, "Fig2_fate_shift.png")

# ═══════════════════════════════════════════════════════════════════════════════
# FIG 3 — velocity stream  (reviewer: "keep, very strong")
# ═══════════════════════════════════════════════════════════════════════════════
print("Generating Fig3_velocity_stream.png ...")
from sklearn.neighbors import NearestNeighbors
from scipy.interpolate import griddata

nbrs = NearestNeighbors(n_neighbors=8).fit(Z2d)
dist_knn, idx_knn = nbrs.kneighbors(Z2d)
w = np.exp(-dist_knn)
w /= w.sum(axis=1, keepdims=True) + 1e-12
V = np.zeros_like(Z2d)
for i in range(len(Z2d)):
    for j, ni in enumerate(idx_knn[i]):
        V[i] += w[i, j] * (Z2d[ni] - Z2d[i])
speed = np.linalg.norm(V, axis=1)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.patch.set_facecolor("#fafafa")

for lbl, col in PALETTE.items():
    mask = lbl_remap == lbl
    axes[0].scatter(Z2d[mask, 0], Z2d[mask, 1],
                    c=col, s=7, alpha=0.28, linewidths=0, rasterized=True)

xi = np.linspace(Z2d[:,0].min(), Z2d[:,0].max(), 28)
yi = np.linspace(Z2d[:,1].min(), Z2d[:,1].max(), 28)
XX, YY = np.meshgrid(xi, yi)
VX = griddata(Z2d, V[:,0], (XX, YY), method="linear", fill_value=0)
VY = griddata(Z2d, V[:,1], (XX, YY), method="linear", fill_value=0)
spd = np.sqrt(VX**2 + VY**2)
spd_norm = spd / (spd.max() + 1e-12)

axes[0].streamplot(xi, yi, VX, VY,
                   color=spd_norm, cmap="plasma",
                   linewidth=1.3, density=1.4, arrowsize=1.4)
axes[0].set_xlabel("Latent dimension 1", fontsize=11)
axes[0].set_ylabel("Latent dimension 2", fontsize=11)
axes[0].set_title("RNA velocity stream\n(KNN transition field on scANVI latent space)",
                  fontsize=11, fontweight="bold")
patches2 = [mpatches.Patch(color=c, label=l) for l, c in PALETTE.items()]
axes[0].legend(handles=patches2, fontsize=8.5, framealpha=0.85)

res_spd  = speed[labels == "malignant"]
sens_spd = speed[labels == "non-malignant"]
df_spd = pd.DataFrame({
    "Displacement magnitude": np.concatenate([res_spd, sens_spd]),
    "Population": ["Resistant"]*len(res_spd) + ["Sensitive"]*len(sens_spd),
})
sns.violinplot(data=df_spd, x="Population", y="Displacement magnitude",
               palette={"Resistant": "#c0392b", "Sensitive": "#2980b9"},
               inner="quartile", cut=0, ax=axes[1], linewidth=1.2)
axes[1].set_title("Transition displacement magnitude\nby cellular population",
                  fontsize=11, fontweight="bold")
axes[1].set_xlabel("")
axes[1].set_ylabel("KNN displacement magnitude", fontsize=10.5)

fig.suptitle("RNA velocity stream structure across the latent melanoma manifold",
             fontsize=12, fontweight="bold", y=1.01)
fig.tight_layout(pad=2.2)
save(fig, "Fig3_velocity_stream.png")

# ═══════════════════════════════════════════════════════════════════════════════
# FIG 4 — fate map heatmap  (reviewer: "strong, keep")
# ═══════════════════════════════════════════════════════════════════════════════
print("Generating Fig4_fate_map_heatmap.png ...")
sort_idx      = np.argsort(trans_labels)
sorted_labels = trans_labels[sort_idx]
n_sens        = (sorted_labels == "non-malignant").sum()
n_res         = (sorted_labels == "malignant").sum()

# Sort terminal states by mean accessibility (reviewer: "sort by accessibility")
mean_access = B.mean(axis=0)
ts_order    = np.argsort(-mean_access)
n_show      = 35
B_sorted    = B[np.ix_(sort_idx, ts_order[:n_show])]
B_base_s    = B_base[np.ix_(sort_idx, ts_order[:n_show])]

cmap_fate = LinearSegmentedColormap.from_list(
    "fate", ["#f0f4ff", "#3498db", "#0a1a6e"], N=256)

fig, axes = plt.subplots(1, 2, figsize=(16, 7))
fig.patch.set_facecolor("#fafafa")

im0 = axes[0].imshow(B_sorted, aspect="auto", cmap=cmap_fate,
                     interpolation="nearest", vmin=0, vmax=B_sorted.max())
plt.colorbar(im0, ax=axes[0], shrink=0.75, label="Absorption probability")
axes[0].axhline(n_sens - 0.5, color="white", lw=2, ls="--", alpha=0.9)
axes[0].text(n_show * 0.01, n_sens / 2, "Sensitive",
             color="white", fontsize=9, va="center", fontweight="bold", rotation=90)
axes[0].text(n_show * 0.01, n_sens + n_res / 2, "Resistant",
             color="white", fontsize=9, va="center", fontweight="bold", rotation=90)
axes[0].set_xlabel(f"Terminal states (top {n_show}, sorted by mean accessibility)",
                   fontsize=10)
axes[0].set_ylabel("Transient cells (sorted by population)", fontsize=10)
axes[0].set_title("Absorbing-state fate map\n(scANVI-conditioned)",
                  fontsize=11, fontweight="bold")

mean_res  = B[trans_labels == "malignant",    :][:, ts_order[:n_show]].mean(axis=0)
mean_sens = B[trans_labels == "non-malignant",:][:, ts_order[:n_show]].mean(axis=0)
x = np.arange(n_show)
axes[1].bar(x - 0.2, mean_res,  0.38, color="#c0392b", alpha=0.82,
            label="Resistant (malignant)")
axes[1].bar(x + 0.2, mean_sens, 0.38, color="#2980b9", alpha=0.82,
            label="Sensitive (non-malignant)")
axes[1].set_xlabel(f"Terminal state index (top {n_show} by accessibility)",
                   fontsize=10)
axes[1].set_ylabel("Mean absorption probability", fontsize=10)
axes[1].set_title("Mean fate accessibility per terminal state\nby cellular population",
                  fontsize=11, fontweight="bold")
axes[1].legend(fontsize=9, framealpha=0.85)
axes[1].set_xlim(-1, n_show)

fig.suptitle("Absorbing-state fate inference: structured long-term terminal accessibility",
             fontsize=12, fontweight="bold", y=1.01)
fig.tight_layout(pad=2.2)
save(fig, "Fig4_fate_map_heatmap.png")

# ═══════════════════════════════════════════════════════════════════════════════
# FIG 5 — diffusion vs velocity  FIX: annotate difference map, sort & reduce
# ═══════════════════════════════════════════════════════════════════════════════
print("Generating Fig5_diffusion_vs_velocity.png ...")
n_show2 = 25   # reviewer: reduce
cmap_a  = LinearSegmentedColormap.from_list("ca", ["#fff9f0","#e67e22","#6e2c00"], N=256)
cmap_b  = LinearSegmentedColormap.from_list("cb", ["#f0f8ff","#2980b9","#0a2342"], N=256)

B_plot  = B[np.ix_(sort_idx, ts_order[:n_show2])]
Bb_plot = B_base[np.ix_(sort_idx, ts_order[:n_show2])]
diff    = B_plot - Bb_plot
vm      = max(B_plot.max(), Bb_plot.max())
vd      = np.abs(diff).max()

fig, axes = plt.subplots(1, 3, figsize=(20, 7))
fig.patch.set_facecolor("#fafafa")

for ax, mat, cmap, title in [
    (axes[0], B_plot,  cmap_a, "Diffusion fate map\n(scANVI-conditioned KNN)"),
    (axes[1], Bb_plot, cmap_b, "Velocity (baseline) fate map\n(PCA-space KNN)"),
]:
    im = ax.imshow(mat, aspect="auto", cmap=cmap,
                   vmin=0, vmax=vm, interpolation="nearest")
    plt.colorbar(im, ax=ax, shrink=0.72, label="Absorption probability")
    ax.axhline(n_sens - 0.5, color="white", lw=2, ls="--")
    ax.text(0.02, 0.03, "Resistant", transform=ax.transAxes,
            color="white", fontsize=8, va="bottom", fontweight="bold")
    ax.text(0.02, n_sens / B_plot.shape[0] + 0.01, "Sensitive",
            transform=ax.transAxes, color="white", fontsize=8,
            va="bottom", fontweight="bold")
    ax.set_title(title, fontsize=11, fontweight="bold")
    ax.set_xlabel(f"Terminal states (top {n_show2}, sorted)", fontsize=10)
    ax.set_ylabel("Transient cells", fontsize=10)

im_d = axes[2].imshow(diff, aspect="auto", cmap="RdBu_r",
                      vmin=-vd, vmax=vd, interpolation="nearest")
cb = plt.colorbar(im_d, ax=axes[2], shrink=0.72,
                  label="Δ Absorption prob. (diffusion − velocity)")
axes[2].axhline(n_sens - 0.5, color="black", lw=1.5, ls="--", alpha=0.5)
axes[2].set_title("Difference map\n(diffusion − velocity baseline)",
                  fontsize=11, fontweight="bold")
axes[2].set_xlabel(f"Terminal states (top {n_show2})", fontsize=10)
axes[2].set_ylabel("Transient cells", fontsize=10)

# ← FIXED: reviewer said "add biological annotation to difference map"
axes[2].text(0.01, 0.99,
             "Red = diffusion-dominant accessibility\n"
             "Blue = velocity-dominant accessibility",
             transform=axes[2].transAxes, ha="left", va="top",
             fontsize=7.5, color="#1a1a1a",
             bbox=dict(boxstyle="round,pad=0.3", fc="white", alpha=0.88))
axes[2].text(0.02, 0.03, "Resistant",
             transform=axes[2].transAxes, color="#555", fontsize=8,
             va="bottom", fontweight="bold")
axes[2].text(0.02, n_sens / B_plot.shape[0] + 0.01, "Sensitive",
             transform=axes[2].transAxes, color="#555", fontsize=8,
             va="bottom", fontweight="bold")

fig.suptitle(
    "Equilibrium diffusion vs velocity-derived fate landscapes — "
    "overlapping but nonidentical terminal accessibility",
    fontsize=12, fontweight="bold", y=1.01)
fig.tight_layout(pad=2.2)
save(fig, "Fig5_diffusion_vs_velocity.png")

# ═══════════════════════════════════════════════════════════════════════════════
# FIG 6 — framework schematic  (reviewer: keep, supplementary preferred)
# ═══════════════════════════════════════════════════════════════════════════════
print("Generating Fig6_framework_overview.png ...")
fig, ax = plt.subplots(figsize=(10, 16))
fig.patch.set_facecolor("#f4f6f9")
ax.set_facecolor("#f4f6f9")
ax.set_xlim(0, 10); ax.set_ylim(0, 20); ax.axis("off")

steps = [
    ("scRNA-seq preprocessing",                  "#1e3a5f", "#d6e4f0"),
    ("scVI/scANVI latent embedding",              "#1a5276", "#d0eaf0"),
    ("Neighbourhood graph construction",         "#145a32", "#d5f5e3"),
    ("RNA velocity estimation  (scVelo)",        "#6e2fa0", "#e8daef"),
    ("Transition operator generation",           "#7d6608", "#fef9e7"),
    ("Entropy-based terminal state detection",   "#922b21", "#fadbd8"),
    ("Absorbing Markov chain inference",         "#1f618d", "#d6eaf8"),
    ("Perturbation-response modelling",          "#0e6655", "#d1f2eb"),
    ("KL fate divergence scoring",               "#6e2fa0", "#e8daef"),
    ("Resistant vs sensitive stability analysis","#c0392b", "#f9ebea"),
]
tool_map = {
    0:"Scanpy", 1:"scVI / scANVI", 2:"Scanpy / scikit-learn",
    3:"scVelo / CellRank", 4:"numpy / scipy",
    5:"scipy (entropy)", 6:"numpy (linalg.inv)",
    7:"custom kernel", 8:"scipy (KL)",
    9:"Mann–Whitney U · KS test",
}
n = len(steps); y_top = 19.0; gap = 1.5; bh = 0.88; bw = 6.4; bx = 1.75

for i, (label, border, fill) in enumerate(steps):
    yc = y_top - i * gap
    rect = mpatches.FancyBboxPatch(
        (bx, yc - bh/2), bw, bh, boxstyle="round,pad=0.12",
        linewidth=2.2, edgecolor=border, facecolor=fill, zorder=3)
    ax.add_patch(rect)
    ax.text(bx + bw/2, yc, f"{i+1}.  {label}",
            ha="center", va="center", fontsize=11.5,
            fontweight="bold", color=border, zorder=4)
    if i < n - 1:
        yt = yc - bh/2
        yb = y_top - (i+1)*gap + bh/2
        ax.annotate("", xy=(5.0, yb+0.04), xytext=(5.0, yt-0.04),
                    arrowprops=dict(arrowstyle="-|>", color="#2c3e50",
                                   lw=2.2, mutation_scale=18), zorder=5)
    ax.text(bx + bw + 0.25, yc, tool_map[i],
            ha="left", va="center", fontsize=9,
            color="#555", style="italic", zorder=4)

ax.set_title(
    "Supplementary Figure 1 — Integrated computational framework\n"
    "for latent dynamical fate inference in melanoma",
    fontsize=13, fontweight="bold", color="#1a1a2e", pad=14)

fig.tight_layout()
save(fig, "Fig6_framework_overview.png")

# ═══════════════════════════════════════════════════════════════════════════════
# ZIP all corrected figures
# ═══════════════════════════════════════════════════════════════════════════════
print("\nPackaging ...")
import zipfile
out = "CORRECTED_FIGURES_FINAL.zip"
figs = sorted(f for f in os.listdir("corrected_figures") if f.endswith(".png"))
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in figs:
        zf.write(f"corrected_figures/{f}", f)

print(f"\nAll done — {len(figs)} figures")
for f in figs:
    sz = os.path.getsize(f"corrected_figures/{f}")
    print(f"  {f:<42} {sz:>9,} bytes")
print(f"\nZIP: {out}  ({os.path.getsize(out):,} bytes)")
