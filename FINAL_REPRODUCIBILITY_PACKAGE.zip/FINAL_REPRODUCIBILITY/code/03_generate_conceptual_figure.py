"""
"Resistance is not only a molecular identity —
it is a dynamically stable region in cellular state space."
"""
import sys
sys.path.insert(0, "/home/runner/workspace/.pythonlibs/lib/python3.11/site-packages")
import warnings; warnings.filterwarnings("ignore")

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.patheffects as pe
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Ellipse, Circle, Arc
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.gridspec as gridspec
from scipy.ndimage import gaussian_filter
from scipy.interpolate import splprep, splev

# ── Colors ────────────────────────────────────────────────────────────────────
C_SENS  = "#2980b9"   # blue  — sensitive
C_RES   = "#c0392b"   # red   — resistant
C_DARK  = "#1a252f"   # dark  — arrows / borders
C_MED   = "#7f8c8d"   # gray  — secondary
C_LIGHT = "#ecf0f1"   # light background
C_GOLD  = "#f39c12"   # therapy / perturbation

np.random.seed(42)

# ── Canvas ────────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(22, 9), facecolor="white")
fig.patch.set_facecolor("white")

gs = gridspec.GridSpec(1, 5, figure=fig,
                       left=0.02, right=0.98,
                       top=0.88, bottom=0.08,
                       wspace=0.06)

axes = [fig.add_subplot(gs[i]) for i in range(5)]
for ax in axes:
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.axis("off")

# Shared arrow style between panels
def inter_arrow(fig, ax_src, ax_dst, label=""):
    """Draw a bold arrow in figure coordinates between two axes."""
    x0 = ax_src.get_position().x1 + 0.003
    x1 = ax_dst.get_position().x0 - 0.003
    y  = (ax_src.get_position().y0 + ax_src.get_position().y1) / 2
    fig.patches.append(mpatches.FancyArrowPatch(
        posA=(x0, y), posB=(x1, y),
        arrowstyle="-|>",
        mutation_scale=18,
        lw=2.0, color=C_DARK,
        transform=fig.transFigure, clip_on=False))

def panel_label(ax, letter, title, subtitle=""):
    ax.text(0.03, 0.98, letter, transform=ax.transAxes,
            fontsize=15, fontweight="bold", color=C_DARK,
            va="top", ha="left")
    ax.text(0.5, 1.04, title, transform=ax.transAxes,
            fontsize=9.5, fontweight="bold", color=C_DARK,
            va="bottom", ha="center")
    if subtitle:
        ax.text(0.5, -0.04, subtitle, transform=ax.transAxes,
                fontsize=7.5, color=C_MED, va="top", ha="center",
                style="italic", multialignment="center")

def smooth_blob(cx, cy, rx, ry, n=200, jitter=0.0):
    t = np.linspace(0, 2*np.pi, n)
    r = 1 + jitter * (np.random.randn(n) * 0.15)
    r = gaussian_filter(r, sigma=8)
    x = cx + rx * r * np.cos(t)
    y = cy + ry * r * np.sin(t)
    return x, y

# ═══════════════════════════════════════════════════════════════════════════════
# PANEL A — BIOLOGICAL PROBLEM
# ═══════════════════════════════════════════════════════════════════════════════
ax = axes[0]
panel_label(ax, "A", "Biological problem",
            "Therapy eliminates sensitive states;\nresistant populations persist")

# Tumor circle — before therapy
tumor_x, tumor_y = 0.35, 0.58
tumor_r = 0.26
theta_t = np.linspace(0, 2*np.pi, 200)
tx = tumor_x + tumor_r * np.cos(theta_t)
ty = tumor_y + tumor_r * np.sin(theta_t)
ax.fill(tx, ty, color="#fdebd0", alpha=0.9, zorder=1)
ax.plot(tx, ty, color="#e59866", lw=1.5, zorder=2)

# Cells inside tumor
n_sens_cells = 22; n_res_cells = 8
ang_s = np.random.uniform(0, 2*np.pi, n_sens_cells)
rad_s = np.random.uniform(0.04, 0.22, n_sens_cells)
xs_s  = tumor_x + rad_s * np.cos(ang_s)
ys_s  = tumor_y + rad_s * np.sin(ang_s)
ax.scatter(xs_s, ys_s, s=55, color=C_SENS, alpha=0.82, zorder=3,
           edgecolors="white", linewidths=0.5)

ang_r = np.random.uniform(0, 2*np.pi, n_res_cells)
rad_r = np.random.uniform(0.04, 0.18, n_res_cells)
xs_r  = tumor_x + rad_r * np.cos(ang_r)
ys_r  = tumor_y + rad_r * np.sin(ang_r)
ax.scatter(xs_r, ys_r, s=55, color=C_RES, alpha=0.9, zorder=4,
           edgecolors="white", linewidths=0.5)

ax.text(tumor_x, tumor_y + tumor_r + 0.04, "Tumour",
        ha="center", fontsize=8, color=C_DARK, fontweight="bold")

# Therapy arrow
ax.annotate("", xy=(0.67, 0.58), xytext=(0.55, 0.58),
            arrowprops=dict(arrowstyle="-|>", color=C_GOLD,
                            lw=2.5, mutation_scale=14))
ax.text(0.61, 0.65, "Therapy", ha="center", fontsize=7.5,
        color=C_GOLD, fontweight="bold")

# After-therapy mini tumor
mini_x, mini_y, mini_r = 0.80, 0.58, 0.14
mt = np.linspace(0, 2*np.pi, 200)
ax.fill(mini_x + mini_r*np.cos(mt), mini_y + mini_r*np.sin(mt),
        color="#fadbd8", alpha=0.9, zorder=1)
ax.plot(mini_x + mini_r*np.cos(mt), mini_y + mini_r*np.sin(mt),
        color="#e74c3c", lw=1.5, zorder=2)
# Only resistant survive
ang_r2 = np.random.uniform(0, 2*np.pi, 6)
rad_r2 = np.random.uniform(0.02, 0.10, 6)
ax.scatter(mini_x + rad_r2*np.cos(ang_r2),
           mini_y + rad_r2*np.sin(ang_r2),
           s=55, color=C_RES, alpha=0.9, zorder=4,
           edgecolors="white", linewidths=0.5)
ax.text(mini_x, mini_y + mini_r + 0.04, "Post-therapy",
        ha="center", fontsize=7.5, color=C_DARK, fontweight="bold")

# Legend dots
ax.scatter([0.10], [0.20], s=55, color=C_SENS, zorder=5, clip_on=False)
ax.text(0.18, 0.20, "Sensitive", va="center", fontsize=7.5, color=C_SENS)
ax.scatter([0.10], [0.12], s=55, color=C_RES, zorder=5, clip_on=False)
ax.text(0.18, 0.12, "Resistant", va="center", fontsize=7.5, color=C_RES)

# ═══════════════════════════════════════════════════════════════════════════════
# PANEL B — LATENT MANIFOLD
# ═══════════════════════════════════════════════════════════════════════════════
ax = axes[1]
panel_label(ax, "B", "scVI/scANVI latent manifold",
            "Continuous transcriptomic state space;\nresistant states occupy compact regions")

# Draw smooth manifold background
cmap_bg = LinearSegmentedColormap.from_list(
    "bg", ["#eaf4fb", "#d6eaf8", "#fde8e8", "#fadbd8"], N=256)

# Build density field
grid_x = np.linspace(0.05, 0.95, 200)
grid_y = np.linspace(0.08, 0.92, 200)
GX, GY = np.meshgrid(grid_x, grid_y)

# Sensitive blob (broad, left-center)
def gauss2d(cx, cy, sx, sy, amp=1.0):
    return amp * np.exp(-0.5*((GX-cx)**2/sx**2 + (GY-cy)**2/sy**2))

field = (gauss2d(0.38, 0.55, 0.22, 0.20, 1.0) +
         gauss2d(0.30, 0.72, 0.18, 0.12, 0.6) +
         gauss2d(0.50, 0.38, 0.16, 0.14, 0.5))
field_r = gauss2d(0.72, 0.60, 0.10, 0.09, 1.4)

# Background manifold extent
manifold_mask = (field + field_r) > 0.08
display_field = np.where(manifold_mask, field - 0.6*field_r, np.nan)
cmap_manifold = LinearSegmentedColormap.from_list(
    "manifold", ["#2980b9", "#85c1e9", "#f9f9f9", "#f1948a", "#c0392b"], N=256)
ax.contourf(GX, GY, field + 0.7*field_r,
            levels=20, cmap=cmap_manifold, alpha=0.55,
            extent=[0.05, 0.95, 0.08, 0.92])

# Scatter points
n_s = 120; n_r = 40
sens_x = np.random.normal(0.38, 0.14, n_s)
sens_y = np.random.normal(0.55, 0.14, n_s)
res_x  = np.random.normal(0.72, 0.06, n_r)
res_y  = np.random.normal(0.60, 0.06, n_r)

ax.scatter(sens_x, sens_y, s=12, color=C_SENS, alpha=0.55,
           linewidths=0, zorder=3, rasterized=True)
ax.scatter(res_x,  res_y,  s=14, color=C_RES,  alpha=0.75,
           linewidths=0, zorder=4, rasterized=True)

# Continuous bridge / transitional cells
t_cells = 20
bridge_x = np.linspace(0.50, 0.66, t_cells) + np.random.randn(t_cells)*0.03
bridge_y = np.linspace(0.55, 0.60, t_cells) + np.random.randn(t_cells)*0.03
bridge_c = plt.cm.RdBu_r(np.linspace(0.2, 0.8, t_cells))
ax.scatter(bridge_x, bridge_y, s=10, color=bridge_c, alpha=0.6,
           linewidths=0, zorder=3.5)

# Annotations
ax.text(0.35, 0.82, "Sensitive states\n(broad, dispersed)",
        ha="center", fontsize=7, color=C_SENS, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.7, ec="none"))
ax.text(0.74, 0.74, "Resistant states\n(compact attractor)",
        ha="center", fontsize=7, color=C_RES, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.7, ec="none"))
ax.annotate("", xy=(0.72, 0.72), xytext=(0.72, 0.68),
            arrowprops=dict(arrowstyle="-|>", color=C_RES, lw=1.2))

ax.set_xlabel("Latent dimension 1", fontsize=7.5, color=C_MED)
ax.set_ylabel("Latent dimension 2", fontsize=7.5, color=C_MED)
ax.xaxis.set_visible(True); ax.yaxis.set_visible(True)
ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)

# ═══════════════════════════════════════════════════════════════════════════════
# PANEL C — DYNAMICAL TRANSITION MODELING
# ═══════════════════════════════════════════════════════════════════════════════
ax = axes[2]
panel_label(ax, "C", "Markov transition dynamics",
            "KNN diffusion + RNA velocity;\nabsorbing chain construction")

# Same manifold background (lighter)
ax.contourf(GX, GY, field + 0.7*field_r,
            levels=16, cmap=cmap_manifold, alpha=0.28)

# Diffusion arrows (symmetric, lighter)
arrow_x  = np.concatenate([sens_x[::7], bridge_x[::3], res_x[::5]])
arrow_y  = np.concatenate([sens_y[::7], bridge_y[::3], res_y[::5]])
np.random.seed(10)
diffs = np.random.randn(len(arrow_x), 2) * 0.035
for i in range(len(arrow_x)):
    ax.annotate("",
        xy=(arrow_x[i]+diffs[i,0], arrow_y[i]+diffs[i,1]),
        xytext=(arrow_x[i], arrow_y[i]),
        arrowprops=dict(arrowstyle="-|>", color=C_MED,
                        lw=0.8, mutation_scale=6, alpha=0.55))

# Velocity arrows (directional, toward resistant attractor)
vel_src_x = np.concatenate([sens_x[::6], bridge_x[::2]])
vel_src_y = np.concatenate([sens_y[::6], bridge_y[::2]])
att_x, att_y = 0.72, 0.60
for i in range(len(vel_src_x)):
    dx = att_x - vel_src_x[i]; dy = att_y - vel_src_y[i]
    norm = np.sqrt(dx**2 + dy**2) + 1e-6
    scale = 0.07 * (1 - norm*0.8)
    if scale > 0.008:
        ax.annotate("",
            xy=(vel_src_x[i] + scale*dx/norm,
                vel_src_y[i] + scale*dy/norm),
            xytext=(vel_src_x[i], vel_src_y[i]),
            arrowprops=dict(arrowstyle="-|>",
                            color="#8e44ad", lw=1.0,
                            mutation_scale=7, alpha=0.7))

# Resistant arrows circling (low-entropy, local)
for angle in np.linspace(0, 2*np.pi, 8, endpoint=False):
    rx0 = att_x + 0.07*np.cos(angle)
    ry0 = att_y + 0.07*np.sin(angle)
    rx1 = att_x + 0.07*np.cos(angle + 0.9)
    ry1 = att_y + 0.07*np.sin(angle + 0.9)
    ax.annotate("", xy=(rx1, ry1), xytext=(rx0, ry0),
                arrowprops=dict(arrowstyle="-|>", color=C_RES,
                                lw=1.1, mutation_scale=7, alpha=0.75))

# Legend
ax.text(0.05, 0.15, "— Diffusion", color=C_MED, fontsize=7)
ax.text(0.05, 0.09, "— Velocity", color="#8e44ad", fontsize=7)
ax.text(0.05, 0.03, "— Resistant confinement", color=C_RES, fontsize=7)

ax.scatter([att_x], [att_y], s=120, color=C_RES, zorder=6,
           edgecolors="white", linewidths=1.2)
ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)

# ═══════════════════════════════════════════════════════════════════════════════
# PANEL D — ABSORBING FATE LANDSCAPE
# ═══════════════════════════════════════════════════════════════════════════════
ax = axes[3]
panel_label(ax, "D", "Absorbing fate landscape",
            "Low-entropy terminal attractor states;\nlong-term fate accessibility")

# Energy landscape (potential surface visualised as 2D contour)
gx = np.linspace(0, 1, 300)
gy = np.linspace(0, 1, 300)
GX2, GY2 = np.meshgrid(gx, gy)

def well(cx, cy, depth, wx, wy):
    return -depth * np.exp(-0.5*((GX2-cx)**2/wx**2 + (GY2-cy)**2/wy**2))

landscape = (well(0.72, 0.55, 2.2, 0.08, 0.08) +   # deep resistant well
             well(0.35, 0.62, 0.9, 0.16, 0.13) +    # shallow sensitive well
             well(0.20, 0.38, 0.6, 0.11, 0.10) +    # another sensitive
             0.5 * (GX2 - 0.5)**2 + 0.3*(GY2-0.5)**2)  # global bowl

cmap_landscape = LinearSegmentedColormap.from_list(
    "land", ["#1a1a2e", "#16213e", "#0f3460", "#533483",
             "#e94560", "#f5a623", "#f9f9f9"], N=512)

cf = ax.contourf(GX2, GY2, landscape, levels=35,
                 cmap=cmap_landscape, alpha=0.92)

# Contour lines
ax.contour(GX2, GY2, landscape, levels=12,
           colors="white", linewidths=0.4, alpha=0.35)

# Trajectory lines — sensitive (wide dispersal)
for _ in range(6):
    start_x = np.random.uniform(0.15, 0.50)
    start_y = np.random.uniform(0.45, 0.80)
    # random walk toward shallow well
    path_x = [start_x]
    path_y = [start_y]
    for step in range(12):
        cx, cy = path_x[-1], path_y[-1]
        grad_x = -0.9*(0.35 - cx) + np.random.randn()*0.04
        grad_y = -0.9*(0.62 - cy) + np.random.randn()*0.04
        path_x.append(cx + 0.03*grad_x)
        path_y.append(cy + 0.03*grad_y)
    ax.plot(path_x, path_y, color=C_SENS, lw=1.3, alpha=0.7)
    ax.annotate("", xy=(path_x[-1], path_y[-1]),
                xytext=(path_x[-2], path_y[-2]),
                arrowprops=dict(arrowstyle="-|>", color=C_SENS,
                                lw=1.0, mutation_scale=7))

# Resistant trajectories (converge tightly into deep well)
for _ in range(6):
    start_x = np.random.uniform(0.55, 0.90)
    start_y = np.random.uniform(0.35, 0.75)
    path_x = [start_x]; path_y = [start_y]
    for step in range(14):
        cx, cy = path_x[-1], path_y[-1]
        grad_x = -2.5*(0.72 - cx) + np.random.randn()*0.015
        grad_y = -2.5*(0.55 - cy) + np.random.randn()*0.015
        path_x.append(cx + 0.025*grad_x)
        path_y.append(cy + 0.025*grad_y)
    ax.plot(path_x, path_y, color=C_RES, lw=1.4, alpha=0.8)
    ax.annotate("", xy=(path_x[-1], path_y[-1]),
                xytext=(path_x[-2], path_y[-2]),
                arrowprops=dict(arrowstyle="-|>", color=C_RES,
                                lw=1.0, mutation_scale=7))

# Deep well marker
ax.scatter([0.72], [0.55], s=160, color=C_RES, zorder=8,
           edgecolors="white", linewidths=2)
ax.text(0.72, 0.43, "Resistant\nattractor",
        ha="center", fontsize=7, color="white", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc=C_RES, alpha=0.85, ec="none"))

ax.scatter([0.35], [0.62], s=90, color=C_SENS, zorder=8,
           edgecolors="white", linewidths=1.5)
ax.text(0.24, 0.76, "Sensitive\nstates",
        ha="center", fontsize=7, color="white", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc=C_SENS, alpha=0.85, ec="none"))

ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)

# ═══════════════════════════════════════════════════════════════════════════════
# PANEL E — PERTURBATION RESPONSE (KEY RESULT)
# ═══════════════════════════════════════════════════════════════════════════════
ax = axes[4]
panel_label(ax, "E", "Perturbation response — Key result",
            "Resistant populations maintain fate stability;\nsensitive states redistribute widely")

# Background split — left sensitive, right resistant
ax.fill_between([0, 0.5], [0, 0], [1, 1],
                color=C_SENS, alpha=0.07)
ax.fill_between([0.5, 1], [0, 0], [1, 1],
                color=C_RES, alpha=0.07)
ax.axvline(0.5, color=C_MED, lw=1.0, ls="--", alpha=0.5)

# Perturbation lightning bolt
bolt_x = [0.50, 0.46, 0.51, 0.47, 0.53]
bolt_y = [0.95, 0.80, 0.77, 0.62, 0.52]
ax.plot(bolt_x, bolt_y, color=C_GOLD, lw=3.0, solid_capstyle="round", zorder=6)
ax.text(0.53, 0.90, "Perturbation", fontsize=7.5,
        color=C_GOLD, fontweight="bold", zorder=7)

# Sensitive side — scattered arrows (wide redistribution)
base_sx, base_sy = 0.22, 0.55
for angle in np.linspace(0.3, 2.9, 7):
    scale = np.random.uniform(0.10, 0.18)
    dx = scale * np.cos(angle) * 1.8
    dy = scale * np.sin(angle) * 0.9
    ax.annotate("",
        xy=(base_sx + dx, base_sy + dy),
        xytext=(base_sx, base_sy),
        arrowprops=dict(arrowstyle="-|>", color=C_SENS,
                        lw=1.4, mutation_scale=9, alpha=0.75))

ax.scatter([base_sx], [base_sy], s=110, color=C_SENS,
           zorder=7, edgecolors="white", linewidths=1.5)
ax.text(0.22, 0.30, "Wide redistribution\nHigh KL divergence",
        ha="center", fontsize=7.5, color=C_SENS, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", alpha=0.85, ec=C_SENS, lw=0.8))

# Resistant side — tight confined arrows (stable)
base_rx, base_ry = 0.78, 0.55
for angle in np.linspace(0, 2*np.pi, 8, endpoint=False):
    scale = 0.06
    dx = scale * np.cos(angle)
    dy = scale * np.sin(angle)
    ax.annotate("",
        xy=(base_rx + 0.5*dx, base_ry + 0.5*dy),
        xytext=(base_rx + dx, base_ry + dy),
        arrowprops=dict(arrowstyle="-|>", color=C_RES,
                        lw=1.4, mutation_scale=8, alpha=0.80))
ax.scatter([base_rx], [base_ry], s=130, color=C_RES,
           zorder=7, edgecolors="white", linewidths=1.8)
ax.text(0.78, 0.30, "Confined stability\nLow KL divergence",
        ha="center", fontsize=7.5, color=C_RES, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", alpha=0.85, ec=C_RES, lw=0.8))

# KL bar comparison (small, bottom)
bar_y = 0.10
ax.annotate("", xy=(0.22, bar_y+0.13), xytext=(0.22, bar_y),
            arrowprops=dict(arrowstyle="-", color=C_MED, lw=0.8))
ax.barh([bar_y + 0.05], [0.28], left=[0.06], height=0.06,
        color=C_SENS, alpha=0.80)
ax.barh([bar_y - 0.02], [0.08], left=[0.06], height=0.06,
        color=C_RES, alpha=0.80)
ax.text(0.35, bar_y + 0.05, "Sensitive KL = 12.33", va="center",
        fontsize=6.5, color=C_SENS)
ax.text(0.35, bar_y - 0.02, "Resistant KL = 11.62  p = 2.7×10⁻⁶",
        va="center", fontsize=6.5, color=C_RES)

# Population labels top
ax.text(0.25, 0.94, "Sensitive", ha="center",
        fontsize=9, fontweight="bold", color=C_SENS)
ax.text(0.75, 0.94, "Resistant", ha="center",
        fontsize=9, fontweight="bold", color=C_RES)

ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)

# ═══════════════════════════════════════════════════════════════════════════════
# Inter-panel arrows
# ═══════════════════════════════════════════════════════════════════════════════
for i in range(4):
    inter_arrow(fig, axes[i], axes[i+1])

# ═══════════════════════════════════════════════════════════════════════════════
# Main title + caption
# ═══════════════════════════════════════════════════════════════════════════════
fig.text(0.50, 0.965,
         "Integrated probabilistic framework for reconstructing dynamical cellular "
         "fate stability in melanoma",
         ha="center", va="bottom", fontsize=13, fontweight="bold",
         color=C_DARK)

fig.text(0.50, 0.002,
         "Figure 1 | Conceptual framework.  "
         "(A) Therapy eliminates sensitive melanoma populations while resistant cells persist.  "
         "(B) scVI/scANVI latent embedding organises cells into a continuous manifold; "
         "resistant states occupy compact, attractor-like regions.  "
         "(C) Markov transition dynamics capture both diffusion and RNA velocity flow; "
         "resistant cells exhibit confined local cycling.  "
         "(D) Absorbing-state fate landscape reveals deep potential wells corresponding "
         "to resistant attractors.  "
         "(E) Under perturbation, sensitive states redistribute widely (high KL divergence) "
         "while resistant states preserve terminal fate accessibility (low KL divergence; "
         "p = 2.74 × 10⁻⁶, Mann–Whitney U test, n = 720 transient cells).  "
         "Resistance is not only a molecular identity — it is a dynamically stable region "
         "in cellular state space.",
         ha="center", va="bottom", fontsize=7.0, color=C_MED,
         wrap=True, multialignment="center")

# ── Save ──────────────────────────────────────────────────────────────────────
import os
out = "Fig_Conceptual_Framework.png"
fig.savefig(out, dpi=220, bbox_inches="tight", facecolor="white")
plt.close(fig)
print(f"Saved: {out}  ({os.path.getsize(out):,} bytes)")
